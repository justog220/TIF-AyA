from Bio import Blast
import os
import re


blast_xml_files = [archivo for archivo in os.listdir("blast_output") if re.findall(r'PROKKA\w+.xml', archivo)]

blast_xml_files.sort()
for blast_xml_file in blast_xml_files:
	result_stream = open("blast_output/" + blast_xml_file, "rb")

	blast_record = Blast.read(result_stream)

	print(blast_xml_file)
	for hit in blast_record:
		print(hit)

	print(">"*80)
