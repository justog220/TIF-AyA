# Anotacion

Para correr script de anotación:

```bash
python anotacion.py
```

Esto va a generar un `csv` y un directorio `blast_output`con la salida de los BLAST.


Para parsear estos xml de la búsqueda con BLAST se generó el script `parse_blast.py`

```bash
python parse_blast.py
```
